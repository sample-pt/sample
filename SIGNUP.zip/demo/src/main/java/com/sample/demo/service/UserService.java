package com.sample.demo.service;

import com.sample.demo.entity.User;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {
    Map<String, User> userDetails = new HashMap<>();
    public Map<String, User> register(User user) {

        User user1 = new User();
        user1.setUserId(user.getUserId());
        user1.setUserName(user.getUserName());
        user1.setUserEmail(user.getUserEmail());
        user1.setPassword(user.getPassword());
        try {
            userDetails.put(user1.getUserId(), user1);
        } catch (Exception e) {
            System.out.println("Something went wrong.");
        }
        return userDetails;
    }

    public void login(User user) {

        Collection<User> val = userDetails.values();

        ArrayList<User> list = new ArrayList<>(val);
        try {
//            if (list.contains(user.getUserEmail())) {
            if(userDetails.containsValue(user.getUserEmail())){
                System.out.println("Login sucessfully");
            } else {
                System.out.println("Email or password wrong");
            }
        } catch (Exception e) {
            System.out.println("Something went wrong.");
        }


    }

    public User getUser(User user) {
        try {
            if (userDetails.containsKey(user.getUserId())) {
                System.out.println("The UserId is Exist");
            } else {
                System.out.println("The UserId is not Exist");
            }
        } catch (Exception e) {
            System.out.println("Something went wrong.");
        }

        return userDetails.get(user.getUserId());
    }


}




