package com.sample.demo.controller;
import com.sample.demo.entity.User;
import com.sample.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
public class UserController {
    @Autowired
    UserService userservice;

    @PostMapping("/register")
    public String saveUser(@RequestBody User user) {
        Map<String, User> userDetails = userservice.register(user);
        System.out.println(userDetails);
        return "User Registration was successful.";
    }

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        userservice.login(user);
        return "Action finished";
    }

    @PostMapping("/getUser")
    public User getUser(@RequestBody User user) {

        User userDetails = userservice.getUser(user);
        System.out.println(userDetails);
        return userDetails;
    }


}
