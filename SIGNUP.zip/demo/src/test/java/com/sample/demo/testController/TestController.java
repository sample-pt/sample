package com.sample.demo.testController;

import org.aspectj.bridge.MessageUtil;
import org.junit.Test;

import static org.springframework.test.util.AssertionErrors.assertEquals;

public class TestController {

    @Test
    public void testPrintMessage() {
        System.out.println("Inside testPrintMessage()");

    }
}
